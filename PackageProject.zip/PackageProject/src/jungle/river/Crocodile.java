package jungle.river;
public class Crocodile {
	 private   int privateA;
	 protected int protectedB;
	 public    int publicC;
	           int defaultD;
	 
	 public Crocodile() { }
	 public void swim() { 
		 System.out.println("crocodile is swimming...");
		 System.out.println("privateA "+privateA);
		 System.out.println("privateA "+protectedB);
		 System.out.println("privateA "+publicC);
		 System.out.println("privateA "+defaultD);
	 }
}
class A {
	void fun() {
		Crocodile c = new Crocodile();
		c.swim();
	}
}