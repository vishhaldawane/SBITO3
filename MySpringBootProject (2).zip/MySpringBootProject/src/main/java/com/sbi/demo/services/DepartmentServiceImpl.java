package com.sbi.demo.services;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.repositories.DepartmentRepository;

@Service		//4
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired		// 3
	DepartmentRepository deptRepository;
	@Override
	public List<Department> fetchAllDepartmentsService() {
			List<Department> deptList= deptRepository.getAllDepartments();
			return deptList;
	}
	
	public Department fetchDepartmentByIdService(int id)
	{
		return deptRepository.getDepartmentById(id);
	}
	public void addDepartmentService(Department dept) {
		deptRepository.insertDepartment(dept);
	}
	public void modifyDepartmentService(Department dept) {
		deptRepository.updateDepartment(dept);
	}
	public void deleteDepartmentByIdService(int deptno) {
		deptRepository.deleteDepartmentById(deptno);
	}

	
}
