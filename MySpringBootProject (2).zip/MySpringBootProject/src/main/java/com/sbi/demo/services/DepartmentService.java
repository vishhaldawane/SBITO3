package com.sbi.demo.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;

@Service
public interface DepartmentService {
	List<Department> fetchAllDepartmentsService();
	Department fetchDepartmentByIdService(int id);
	
	void addDepartmentService(Department dept);
	void modifyDepartmentService(Department dept);
	void deleteDepartmentByIdService(int deptno);
	
}
