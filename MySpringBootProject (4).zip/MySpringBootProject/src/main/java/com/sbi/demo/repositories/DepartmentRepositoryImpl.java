package com.sbi.demo.repositories;
//God is also blessing us in muted learning
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentNotFoundException;

@Repository("deptRepo")
public class DepartmentRepositoryImpl implements DepartmentRepository 
{

	//where is the entitymanagerfactory -
	
	//EntityManagerFactory entityManagerFactory;
	@PersistenceContext
	EntityManager entityManager;
	
	public DepartmentRepositoryImpl() {
	//	entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
	//	entityManager =entityManagerFactory.createEntityManager();
		System.out.println("DepartmentRepositoryImpl()....");
	}
	
	@Override
	public List<Department> getAllDepartments() {
		List<Department> deptList = null;
		try {
			TypedQuery<Department> query = entityManager.createQuery("from Department", Department.class);
			deptList = query.getResultList();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return deptList;
	}
	
	public Department getDepartmentById(int id) throws DepartmentNotFoundException
	{
		Department dept = entityManager.find(Department.class, id);
		if(dept==null) {
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
		return dept;
	}
	
	@Transactional
	public void insertDepartment(Department dept) {
		entityManager.persist(dept);
	}
	@Transactional
	public void updateDepartment(Department dept) {
		entityManager.merge(dept);
	}
	@Transactional
	public void deleteDepartmentById(int id) {
		Department dept = entityManager.find(Department.class,id);
		entityManager.remove(dept);
	}
	
	

}
