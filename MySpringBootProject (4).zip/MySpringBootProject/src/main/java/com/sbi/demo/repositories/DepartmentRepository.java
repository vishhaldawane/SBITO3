package com.sbi.demo.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentNotFoundException;

@Repository // <-- same as component	
public interface DepartmentRepository {
	public List<Department> getAllDepartments();
	Department getDepartmentById(int id) throws DepartmentNotFoundException;
	
	void insertDepartment(Department dept);
	void updateDepartment(Department dept);
	void deleteDepartmentById(int id);
	
	
	//insertDepartment
	//updateDepartment
	//deleteDepartment
	//getDepartment - single
	

}
