import java.util.List;

public interface FlightDAO {
	Flight findFlightById(int flno);
	List<Flight> findAllFlights();
	void saveFlight(Flight flight) ;
	void updateFlight(Flight flight) ;
	void deleteFlight(int flno);
}
