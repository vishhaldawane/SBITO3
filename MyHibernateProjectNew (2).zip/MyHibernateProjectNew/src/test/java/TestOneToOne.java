import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import one2one.Passport;
import one2one.Person;

public class TestOneToOne {

	EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
	//System.out.println("EntityManagerFactory : "+entityManagerFactory);
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	//System.out.println("EntityManager: "+entityManager);

	
	@Test
	public void assignNewPassportToNewPersonTests() {
		
	
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			Person perObj = new Person();
			perObj.setPersonId(1);
			perObj.setAge(22);
			perObj.setGender('M');
			perObj.setName("Jack");
			
			Passport passport = new Passport();
			passport.setPassportNumber("T-123123123");
			passport.setPassportIssuedDate(LocalDate.now());
			passport.setPassportExpiryDate(LocalDate.of(2032,05,10));
			passport.setPassportIssuedBy("Govt. Of India");
			passport.setNationality("Indian");
			
			perObj.setPassport(passport); //setting the foreign key value
			passport.setPerson(perObj); //setting the foreign key value
			
			System.out.println("trying to persist....");			
				entityManager.persist(perObj);
				entityManager.persist(passport);				
			System.out.println("Persisted....");
		et.commit();
	}
	
	@Test
	public void findPersonBasedOnPassportTest() {
		Passport passport = entityManager.find(Passport.class, "T-123123123");
		System.out.println("Passport issued by  : "+passport.getPassportIssuedBy());
		System.out.println("Passport issued on  : "+passport.getPassportIssuedDate());
		System.out.println("Passport expiry on  : "+passport.getPassportExpiryDate());
		System.out.println("Passport nationality: "+passport.getNationality());
		Person person = passport.getPerson();
		System.out.println("Person Name   : "+person.getName());
		System.out.println("Person Gender : "+person.getGender());
		System.out.println("Person Age    : "+person.getAge());
		
	}
	
	
	@Test
	public void addPersonWithoutPassport() {
		
		Person person = new Person();
		person.setPersonId(2);
		person.setAge(22);
		person.setGender('F');
		person.setName("Julia");

		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			entityManager.persist(person);
		et.commit();
	}
	
	@Test
	public void addPassportWithoutPerson() {
		
		Passport passport = new Passport();
		passport.setPassportNumber("T-623623623");
		passport.setPassportIssuedDate(LocalDate.now());
		passport.setPassportExpiryDate(LocalDate.of(2032,05,10));
		passport.setPassportIssuedBy("Govt. Of India");
		passport.setNationality("Indian");

		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			entityManager.persist(passport);
		et.commit();
	}

	@Test 
	public void assignExistingPassportToExistingPerson()
	{
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			Person person = entityManager.find(Person.class, 2);
			Passport passport = entityManager.find(Passport.class, "T-623623623");
			passport.setPerson(person);//fill up the foreign key person_id
			entityManager.merge(passport);
		et.commit();
	}
}
