package jungle.river;

public class Allegator extends Crocodile {

	public void swim() { 
		 System.out.println("crocodile is swimming...");
		 System.out.println("privateA "+privateA);
		 System.out.println("privateA "+protectedB);
		 System.out.println("privateA "+publicC);
		 System.out.println("privateA "+defaultD);
	 }
	public void swimming() {
		Crocodile croc = null;

		System.out.println("privateA "+croc.privateA);
		System.out.println("privateA "+croc.protectedB);
		System.out.println("privateA "+croc.publicC);
		System.out.println("privateA "+croc.defaultD); 
		
	}
	 
}
