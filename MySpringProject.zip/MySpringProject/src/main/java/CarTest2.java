import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.hdfc.Car;
import com.hdfc.Engine;
import com.hdfc.Piston;

public class CarTest2 {
	public static void main(String[] args) {
		
		System.out.println("trying to load the application context...");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspring3.xml");
		System.out.println("application context...loaded.....");
		System.out.println("-------------------");
		Car carObj = (Car) container.getBean("x");
		carObj.startTheCar();
		System.out.println("carObj "+carObj);
		System.out.println("-------------------");
		Car carObj2 = (Car) container.getBean("x");
		carObj2.startTheCar();
		System.out.println("carObj2 "+carObj2);
		
		carObj.startTheCar();
		
		
		
	}
}
