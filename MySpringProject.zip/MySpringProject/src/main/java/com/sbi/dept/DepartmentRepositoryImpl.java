package com.sbi.dept;
//God is also blessing us in muted learning
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

@Repository("deptRepo")
class DepartmentRepositoryImpl implements DepartmentRepository 
{

	//where is the entitymanagerfactory -
	
	EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;
	
	public DepartmentRepositoryImpl() {
		entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		entityManager =entityManagerFactory.createEntityManager();
		System.out.println("DepartmentRepositoryImpl()....");
	}
	
	@Override
	public List<Department> getAllDepartments() {
		TypedQuery<Department> query = entityManager.createQuery("from Department", Department.class);
		return query.getResultList();
	}

}
