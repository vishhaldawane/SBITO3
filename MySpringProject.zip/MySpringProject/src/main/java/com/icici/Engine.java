package com.icici;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("eng")
public class Engine {
	
	@Autowired
	Piston pist;
	
	public void igniteTheEngine() {
		pist.firePiston();
		System.out.println("com.icici: igniteTheEngine()....");
	}
}
