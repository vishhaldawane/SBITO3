package com.sbi.demo.entity;


public class AnyObject {
	 public int dno; 
	 public int eno; //empno
	 public int cno; //custid
	 
	public int getDno() {
		return dno;
	}
	public void setDno(int dno) {
		this.dno = dno;
	}
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}

	 
}
