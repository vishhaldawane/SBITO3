package com.sbi.demo.controllers;

import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.entity.AnyObject;
import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;
import com.sbi.demo.services.DepartmentService;

@CrossOrigin
@RestController
@RequestMapping("/depts")
public class DepartmentController {

	@PostMapping("/any")
	public String updateThreeTables(@RequestBody AnyObject ao) {
		System.out.println("dno : "+ao.getDno());
		System.out.println("eno : "+ao.getEno());
		System.out.println("cno : "+ao.getCno());
		deptService.makeChangesInThreeTablesService(ao);
		return "records are updated....";
	}
	
	
	
	@RequestMapping("/welcome")
	public String greet() { // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: greet() is invoked....");
	  return "<h1>Welcome to Department Controller</h1>";
	}
	
	@Autowired
	DepartmentService deptService;// new DepartmentServiceImpl();

	@RequestMapping("/")
	public List<Department> allDepts() { // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: allDepts() is invoked....");
	  return deptService.fetchAllDepartmentsService();
	}
	@RequestMapping("/{dno}")
	public Department findSingleDept(@PathVariable("dno") int deptno) throws DepartmentNotFoundException { // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: findSingleDept(int) is invoked....");
	  Department dept=null;
	  try {
		dept = deptService.fetchDepartmentByIdService(deptno);
	  } catch (DepartmentNotFoundException e) {
		//return ResponseEntity.status(404).build();
		  throw e;
	  }
	  //return ResponseEntity.ok().body(dept);
	  return dept;
	}
	
	@PostMapping("/addDept")
	public String addNewDepartment(@RequestBody Department deptBody) throws DepartmentAlreadyExistsException 
	{ 
	  System.out.println("DepartmentController: addNewDepartment(Department) is invoked....");
		try {
			deptService.addDepartmentService(deptBody);
		} catch (DepartmentAlreadyExistsException e) {
			throw e;
		}
		return "Department Added";
	}
	
	@PutMapping("/updateDept")
	public String updateExistingDepartment(@RequestBody Department deptBody) throws DepartmentNotFoundException 
	{ // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: updateExistingDepartment(Department) is invoked....");
		try {
			deptService.modifyDepartmentService(deptBody);
		} catch (DepartmentNotFoundException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		return "Department updated successfully....";
	}
	@DeleteMapping("/deleteDept/{id}")
	public String deleteExistingDepartment(@PathVariable("id") int deptNoToDelete) throws DepartmentNotFoundException 
	{ // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: deleteExistingDepartment(Department) is invoked....");
		try {
			deptService.deleteDepartmentByIdService(deptNoToDelete);
		} catch (DepartmentNotFoundException e) {
			throw e;
		}
	  return "Department Deleted successfully....";
	}
	
}


