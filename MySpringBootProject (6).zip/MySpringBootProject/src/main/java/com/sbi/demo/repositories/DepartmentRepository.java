package com.sbi.demo.repositories;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;

@Repository // <-- same as component	
public interface DepartmentRepository {
	public List<Department> getAllDepartments();
	Department getDepartmentById(int id) throws DepartmentNotFoundException;
	
	void insertDepartment(Department dept) throws DepartmentAlreadyExistsException;
	void updateDepartment(Department dept) throws DepartmentNotFoundException;
	void deleteDepartmentById(int id) throws DepartmentNotFoundException;
	
	void makeChangesInThreeTables(int deptno, int empno, int custid);
	//insertDepartment
	//updateDepartment
	//deleteDepartment
	//getDepartment - single
	

}
