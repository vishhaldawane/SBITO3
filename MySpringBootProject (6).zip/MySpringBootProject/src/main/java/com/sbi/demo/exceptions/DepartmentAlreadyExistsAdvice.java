package com.sbi.demo.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class DepartmentAlreadyExistsAdvice {

	@ResponseBody
	@ExceptionHandler(DepartmentAlreadyExistsException.class)
	@ResponseStatus(HttpStatus.FOUND)
	String departmentAlreadyFoundFoundHandler(DepartmentAlreadyExistsException ex)
	{
		System.out.println("departmentNotFoundHandler.....");
		return ex.getMessage() + " its already there!!!";
	}
}
