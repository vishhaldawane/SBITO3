package com.sbi.demo.repositories;
//God is also blessing us in muted learning
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;

@Repository("deptRepo")
public class DepartmentRepositoryImpl implements DepartmentRepository 
{
	@Transactional
	public void makeChangesInThreeTables(int deptno, int empno, int custid)
	{
		System.out.println("makeChangesInThreeTables(int,int,int) is fired....");
		Query query1 = entityManager.createNativeQuery("update dept set dname='MAKTNG' where deptno=:x");
		Query query2 = entityManager.createNativeQuery("update emp  set ename='JOHNY' where EMPNO=:y");
		Query query3 = entityManager.createNativeQuery("update customer set name='WALKER' where custid=:z");
		
		query1.setParameter("x", deptno);
		query2.setParameter("y", empno);
		query3.setParameter("z", custid);
		
		query1.executeUpdate();
		query2.executeUpdate();
		query3.executeUpdate();
		System.out.println("DATA IS UPDATED...");
	}
	//where is the entitymanagerfactory -
	
	//EntityManagerFactory entityManagerFactory;
	@PersistenceContext
	EntityManager entityManager;
	
	public DepartmentRepositoryImpl() {
	//	entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
	//	entityManager =entityManagerFactory.createEntityManager();
		System.out.println("DepartmentRepositoryImpl()....");
	}
	
	@Override
	public List<Department> getAllDepartments() {
		List<Department> deptList = null;
		try {
			TypedQuery<Department> query = entityManager.createQuery("from Department", Department.class);
			deptList = query.getResultList();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return deptList;
	}
	
	public Department getDepartmentById(int id) throws DepartmentNotFoundException
	{
		Department dept = entityManager.find(Department.class, id);
		if(dept==null) {
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
		return dept;
	}
	
	@Transactional
	public void insertDepartment(Department dept)throws DepartmentAlreadyExistsException 
	{
		Department deptTemp = entityManager.find(Department.class, dept.getDepartmentNumber());
		if(deptTemp!=null) {
			throw new DepartmentAlreadyExistsException("This department number already exists!!!! : "+deptTemp.getDepartmentNumber());
		}
		entityManager.persist(dept);
	}
	@Transactional
	public void updateDepartment(Department dept) throws DepartmentNotFoundException {
		Department deptTemp = entityManager.find(Department.class, dept.getDepartmentNumber());
		if(deptTemp == null) {
			throw new DepartmentNotFoundException("Department NOT found : "+dept.getDepartmentNumber());
		}
		entityManager.merge(dept);
	}
	@Transactional
	public void deleteDepartmentById(int id) throws DepartmentNotFoundException{
		Department dept = entityManager.find(Department.class,id);
		if(dept==null){
			throw new DepartmentNotFoundException("Department NOT found : "+id);
		}
		entityManager.remove(dept);
	}
	
	

}
