import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Test;

public class TestFlight {
	
	@Test
	public void deleteTest() {
		EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
		System.out.println("EntityManagerFactory : "+entityManagerFactory);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("EntityManager: "+entityManager);
	
		
		
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			Flight f= entityManager.find(Flight.class,3);
			System.out.println("f is found "+f.getFlightName());
			System.out.println("trying to Remove....");			
				entityManager.remove(f);
			System.out.println("Removed....");
		et.commit();
	}
	
	@Test 
	public void allFlightsTest() {
	
		EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
		System.out.println("EntityManagerFactory : "+entityManagerFactory);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("EntityManager: "+entityManager);
		Query query = entityManager.createQuery("from Flight"); //POJO name, not the table name - JPQL
		List<Flight> allFlights = query.getResultList();
		
		for(Flight f : allFlights) {
			System.out.println("Flight number : "+f.getFlightNumber());
			System.out.println("Flight name   : "+f.getFlightName());
			System.out.println("Flight source : "+f.getFlightSource());
			System.out.println("Flight dest   : "+f.getFlightDestination());
			System.out.println("Flight arrtime: "+f.getFlightArrivalAtDestination());
			System.out.println("Flight deptime: "+f.getFlightDepartureFromSource());
			System.out.println("Flight nop    : "+f.getNumberOfPassengers());
			System.out.println("Flight cost   : "+f.getFlightTicketCost());
			System.out.println("-----------------");
		}
		
		
	}
	
	@Test
	public void testFindFlight() {
		EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
		System.out.println("EntityManagerFactory : "+entityManagerFactory);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("EntityManager: "+entityManager);
		
		//attached object 
		Flight f = entityManager.find(Flight.class, 6);
		System.out.println("Flight number : "+f.getFlightNumber());
		System.out.println("Flight name   : "+f.getFlightName());
		System.out.println("Flight source : "+f.getFlightSource());
		System.out.println("Flight dest   : "+f.getFlightDestination());
		System.out.println("Flight arrtime: "+f.getFlightArrivalAtDestination());
		System.out.println("Flight deptime: "+f.getFlightDepartureFromSource());
		System.out.println("Flight nop    : "+f.getNumberOfPassengers());
		System.out.println("Flight cost   : "+f.getFlightTicketCost());
	}
	
	@Test
	public void testModifyFlight() {
		EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
		System.out.println("EntityManagerFactory : "+entityManagerFactory);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("EntityManager: "+entityManager);
		
		//attached object
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
		
		Flight f = entityManager.find(Flight.class, 6);
		System.out.println("Flight number : "+f.getFlightNumber());
		System.out.println("Flight name   : "+f.getFlightName());
		System.out.println("Flight source : "+f.getFlightSource());
		System.out.println("Flight dest   : "+f.getFlightDestination());
		System.out.println("Flight arrtime: "+f.getFlightArrivalAtDestination());
		System.out.println("Flight deptime: "+f.getFlightDepartureFromSource());
		System.out.println("Flight nop    : "+f.getNumberOfPassengers());
		System.out.println("Flight cost   : "+f.getFlightTicketCost());
	
		f.setFlightName("Air India");
		f.setFlightSource("New Mumbai");
		f.setFlightDestination("New Paris");
		float currentCost = f.getFlightTicketCost();
		float newCost = currentCost + currentCost*0.10f;
		f.setFlightTicketCost(newCost);
		
		System.out.println("Object updated...");
			entityManager.merge(f);
		System.out.println("...hence row is also updated....");
	
		et.commit();
	}
	
	
	@Test
	public void testModifyFlight2() {
		EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
		System.out.println("EntityManagerFactory : "+entityManagerFactory);
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		System.out.println("EntityManager: "+entityManager);
		
		//attached object
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
		
		
		Flight f = new Flight(); //TRANSIENT
		f.setFlightNumber(12);
		f.setFlightName("Jet Airways");
		f.setFlightSource("Mumbai");
		f.setFlightDestination("Jaipur");
		System.out.println("Object updated...");
			entityManager.merge(f);
		System.out.println("...hence row is also updated....");
		et.commit();
	}
	
	
	
	@Test
	public void testInsertFlight() {
			EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
			System.out.println("EntityManagerFactory : "+entityManagerFactory);
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			System.out.println("EntityManager: "+entityManager);
			
			EntityTransaction et = entityManager.getTransaction();
			et.begin();
			//transient object = till now it is not yet stored in the db , it in the memory
					Flight flightObj1 = new Flight();
					System.out.println("Flight object is created....");
					flightObj1.setFlightName("Indian Airlines");
					flightObj1.setFlightSource("Mumbai");
					flightObj1.setFlightDestination("Nagpur");
					flightObj1.setFlightDepartureFromSource(LocalDateTime.of(2022,05,10,12,50));
					flightObj1.setFlightArrivalAtDestination(LocalDateTime.of(2022,05,10,13,50));
					flightObj1.setNumberOfPassengers(120);
					flightObj1.setFlightTicketCost(6500);
					
					Flight flightObj2 = new Flight();
					System.out.println("Flight object is created....");
					flightObj2.setFlightName("Go Air");
					flightObj2.setFlightSource("Mumbai");
					flightObj2.setFlightDestination("Kolkatta");
					flightObj2.setFlightDepartureFromSource(LocalDateTime.of(2022,05,10,18,50));
					flightObj2.setFlightArrivalAtDestination(LocalDateTime.of(2022,05,10,20,50));
					flightObj2.setNumberOfPassengers(150);
					flightObj2.setFlightTicketCost(8500);
					
					Flight flightObj3 = new Flight();
					System.out.println("Flight object is created....");
					flightObj3.setFlightName("British Airways");
					flightObj3.setFlightSource("Mumbai");
					flightObj3.setFlightDestination("London");
					flightObj3.setFlightDepartureFromSource(LocalDateTime.of(2022,05,10,22,00));
					flightObj3.setFlightArrivalAtDestination(LocalDateTime.of(2022,05,10,07,00));
					flightObj3.setNumberOfPassengers(170);
					flightObj3.setFlightTicketCost(65500);
					
					Flight flightObj4 = new Flight();
					System.out.println("Flight object is created....");
					flightObj4.setFlightName("Air America");
					flightObj4.setFlightSource("Mumbai");
					flightObj4.setFlightDestination("New Jersey");
					flightObj4.setFlightDepartureFromSource(LocalDateTime.of(2022,05,10,20,50));
					flightObj4.setFlightArrivalAtDestination(LocalDateTime.of(2022,05,11,23,50));
					flightObj4.setNumberOfPassengers(120);
					flightObj4.setFlightTicketCost(57500);
					
					Flight flightObj5 = new Flight();
					System.out.println("Flight object is created....");
					flightObj5.setFlightName("Air France");
					flightObj5.setFlightSource("Mumbai");
					flightObj5.setFlightDestination("Paris");
					flightObj5.setFlightDepartureFromSource(LocalDateTime.of(2022,05,10,20,50));
					flightObj5.setFlightArrivalAtDestination(LocalDateTime.of(2022,05,11,22,50));
					flightObj5.setNumberOfPassengers(130);
					flightObj5.setFlightTicketCost(67500);
					
					
					System.out.println("Flight object is filled up....");
					
					System.out.println("Trying to persist the Flight object ....");
					entityManager.persist(flightObj1);
					entityManager.persist(flightObj2);
					entityManager.persist(flightObj3);
					entityManager.persist(flightObj4);
					entityManager.persist(flightObj5);
					
					System.out.println("Persisted the Flight object ....");
			et.commit();
			
	}
}
