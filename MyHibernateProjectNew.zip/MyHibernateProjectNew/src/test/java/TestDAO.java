import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class TestDAO {
	
	FlightDAO flightDao = new FlightDAOImpl();
	
	@Test
	public void testSelectDAO() {
		
		Flight f = flightDao.findFlightById(1);
		Assertions.assertTrue(f!=null);
		System.out.println("Flight number : "+f.getFlightNumber());
		System.out.println("Flight name   : "+f.getFlightName());
		System.out.println("Flight source : "+f.getFlightSource());
		System.out.println("Flight dest   : "+f.getFlightDestination());
		System.out.println("Flight arrtime: "+f.getFlightArrivalAtDestination());
		System.out.println("Flight deptime: "+f.getFlightDepartureFromSource());
		System.out.println("Flight nop    : "+f.getNumberOfPassengers());
		System.out.println("Flight cost   : "+f.getFlightTicketCost());
	
	}
}
