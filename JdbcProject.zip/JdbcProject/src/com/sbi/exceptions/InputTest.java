package com.sbi.exceptions;

import java.util.Scanner;

public class InputTest {
	public static void main(String[] args) {
		
		int i;
		String j;
		String k;
		float l;
		
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		Scanner scan3 = new Scanner(System.in);
		Scanner scan4 = new Scanner(System.in);
		
		System.out.println("Enter number : ");
		i = scan1.nextInt(); //100<-

		System.out.println("Enter string : ");
		j = scan2.nextLine(); //new york <-
		
		System.out.println("Enter another string : ");
		k = scan3.nextLine(); //NEW JERSEY

		System.out.println("Enter float : ");
		l = scan4.nextFloat(); //45.67
		
		System.out.println("i : "+i+" j : "+j+" k : "+k+" l : "+l);
	}
}

