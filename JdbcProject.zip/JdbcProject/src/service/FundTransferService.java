package service;

import dao.bankaccount.BankAccount;

public interface FundTransferService {
	public void fundsTransferService(BankAccount source, BankAccount  target, double amounToTransfer);
}
