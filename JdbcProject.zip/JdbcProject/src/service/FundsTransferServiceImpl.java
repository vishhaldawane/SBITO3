package service;

import dao.bankaccount.BankAccount;
import dao.bankaccount.BankAccountDAO;
import dao.bankaccount.BankAccountDAOImpl;
import dao.bankapplicant.BankApplicantDAO;
import dao.bankapplicant.BankApplicantDAOImpl;
import dao.payee.Payee;
import dao.payee.PayeeDAO;
import dao.payee.PayeeDAOImpl;

public class FundsTransferServiceImpl implements FundTransferService {

	BankApplicantDAO appDao = new BankApplicantDAOImpl();
	BankAccountDAO accDao = new BankAccountDAOImpl();
	PayeeDAO payeeDao = new PayeeDAOImpl();
	
	@Override
	public void fundsTransferService(BankAccount source, BankAccount target, double amounToTransfer) {
		
		BankAccount foundSource = accDao.findBankAccountById(source.getAccountNumber());
		if(foundSource!=null) {
			BankAccount foundTarget = accDao.findBankAccountById(target.getAccountNumber());
			if(foundTarget!=null) {
				
				int custid = foundSource.getCustmerId(); //1
				Payee payee = payeeDao.findPayeeByAccountNumber(foundTarget.getAccountNumber());
				
				if(payee.getApplicantId() == custid) {
					double currentSourceBalance=foundSource.getAccountBalance();
					if(currentSourceBalance > amounToTransfer) {
						double currentTargetBalance = foundTarget.getAccountBalance();
						
						double newSourceBalance = currentSourceBalance - amounToTransfer;
						double newTargetBalance = currentTargetBalance + amounToTransfer;
						
						foundSource.setAccountBalance(newSourceBalance);
						foundTarget.setAccountBalance(newTargetBalance);
						
						accDao.updateBankAccount(foundSource);
						accDao.updateBankAccount(foundTarget);
						System.out.println("TRANSFERRED!!!!!");
					}
					else {
						throw new RuntimeException("Insufficient funds.....");
					}
				}
				else {
					throw new RuntimeException("Payee not found.....");
				}
			}
			else {
				throw new RuntimeException("Target Account not found.....");
			}
		}
		else {
			throw new RuntimeException("Source Account not found.....");
		}
	}
}
