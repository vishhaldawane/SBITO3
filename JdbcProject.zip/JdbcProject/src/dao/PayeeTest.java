package dao;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.payee.Payee;
import dao.payee.PayeeDAO;
import dao.payee.PayeeDAOImpl;

public class PayeeTest {

	PayeeDAO payeeDao = new PayeeDAOImpl();
	
	@Test
	public void findPayeeTest() {
		
		Payee payee = payeeDao.findPayeeByAccountNumber(623623);
		Assertions.assertTrue(payee!=null);
		System.out.println("Payee Name  "+payee.getPayeeName());
		System.out.println("Payee limit "+payee.getPayeeLimit());
	}
}
