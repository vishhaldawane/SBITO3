package dao;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import dao.bankaccount.BankAccount;
import dao.bankaccount.BankAccountDAO;
import dao.bankaccount.BankAccountDAOImpl;

public class BankAccountTest {
	
	BankAccountDAO baAccDao = new BankAccountDAOImpl();
	
	@Test
	public void testFindAccount() {
		BankAccount baAcc = baAccDao.findBankAccountById(123123);
		Assertions.assertTrue(baAcc!=null);
		System.out.println("Got the object....."+baAcc);
	}
	
	@Test
	public void testDebitFromAccount() {
		BankAccount baAcc = baAccDao.findBankAccountById(120620);
		Assertions.assertTrue(baAcc!=null);
		System.out.println("Found the bankAccount ");
		double currentBalance = baAcc.getAccountBalance();
		System.out.println("Found the balance "+currentBalance);
		double newBalance = currentBalance - 500;
		System.out.println("Calculated the new balance "+newBalance);
		baAcc.setAccountBalance(newBalance);
		System.out.println("Setting the new balance ");
		baAccDao.updateBankAccount(baAcc);
		System.out.println("Updated the balance....");
		
		/*BankAccount ba= new BankAccount();
		ba.setAccountNumber(120620);
		ba.setAccountBalance(4000);
		baAccDao.updateBankAccount(ba);*/
	}
}
