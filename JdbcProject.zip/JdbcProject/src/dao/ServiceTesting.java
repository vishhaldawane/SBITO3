package dao;

import dao.bankaccount.BankAccount;
import service.FundTransferService;
import service.FundsTransferServiceImpl;

public class ServiceTesting {
	public static void main(String[] args) {
		
		FundTransferService fts = new FundsTransferServiceImpl();
		
		BankAccount source = new BankAccount();
		BankAccount target = new BankAccount();
		
		source.setAccountNumber(123123);
		target.setAccountNumber(623623);
		double amount=6500;
		fts.fundsTransferService(source, target, amount);
	}
}
