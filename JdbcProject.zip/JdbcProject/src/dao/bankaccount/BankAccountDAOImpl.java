package dao.bankaccount;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dao.bankapplicant.BankApplicant;

public class BankAccountDAOImpl implements BankAccountDAO {
	
	Connection conn;
	
	public BankAccountDAOImpl() {
		System.out.println("BankAccountDAOImpl() ctor..");

		try {
			//DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver loaded.../registered....");

			//conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "sysgitc");
			System.out.println("Connected to the db...."+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public BankAccount findBankAccountById(int acno) {
		BankAccount ba = null;
		try {
			Statement st = conn.createStatement();
			System.out.println("statement is created..."+st);
			
			ResultSet rs = st.executeQuery("SELECT * FROM bank_account where account_number="+acno);
			System.out.println("query fired...got the results....");
			
			
			if(rs.next()) {
				
				ba = new BankAccount();
				
				ba.setAccountNumber(rs.getInt(1));
				ba.setAccountOpeningDate(rs.getDate(2));
				ba.setAccountBalance(rs.getDouble(3));
				ba.setCustmerId(rs.getInt(4));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return ba;
	}

	@Override
	public List<BankAccount> findAllBankAccounts() {
		List<BankAccount> bankAccList = new ArrayList<BankAccount>(); 
		BankAccount ba = null;
		try {
			Statement st = conn.createStatement();
			System.out.println("statement is created..."+st);
			
			ResultSet rs = st.executeQuery("SELECT * FROM bank_account");
			System.out.println("query fired...got the results....");
			
			
			while(rs.next()) {
				
				ba = new BankAccount();
				
				ba.setAccountNumber(rs.getInt(1));
				ba.setAccountOpeningDate(rs.getDate(2));
				ba.setAccountBalance(rs.getDouble(3));
				ba.setCustmerId(rs.getInt(4));
				
				bankAccList.add(ba);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bankAccList;
	}

	@Override
	public void saveBankAccount(BankAccount ba) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO BANK_account VALUES (?,?,?,?) ");
			pst.setInt(1, ba.getAccountNumber());
			pst.setDate(2, ba.getAccountOpeningDate());
			pst.setDouble(3, ba.getAccountBalance());
			pst.setInt(4, ba.getCustmerId());
			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row inserted..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updateBankAccount(BankAccount ba) {
		
		try {
			PreparedStatement pst = conn.prepareStatement("update BANK_account set ACCOUNT_BALANCE=? where account_number=?");
			pst.setDouble(1, ba.getAccountBalance());
			pst.setInt(2, ba.getAccountNumber());
			
			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row updated..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void deleteBankAccountById(int acno) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("delete from BANK_account where account_number=?");
			pst.setDouble(1, acno);
			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row deleted..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
