package dao.bankaccount;

import java.util.List;

public interface BankAccountDAO {
	//CRUD
	BankAccount findBankAccountById(int acno);
	List<BankAccount> findAllBankAccounts();
	void saveBankAccount(BankAccount obj);
	void updateBankAccount(BankAccount obj);
	void deleteBankAccountById(int acno);
}
