package dao.payee;

public class Payee {
	private int payeeAccountNumber;
	private String payeeName;
	private String payeeNickName;
	private double payeeLimit;
	private int applicantId;
	
	public int getPayeeAccountNumber() {
		return payeeAccountNumber;
	}
	public void setPayeeAccountNumber(int payeeAccountNumber) {
		this.payeeAccountNumber = payeeAccountNumber;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public String getPayeeNickName() {
		return payeeNickName;
	}
	public void setPayeeNickName(String payeeNickName) {
		this.payeeNickName = payeeNickName;
	}
	public double getPayeeLimit() {
		return payeeLimit;
	}
	public void setPayeeLimit(double payeeLimit) {
		this.payeeLimit = payeeLimit;
	}
	public int getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(int applicantId) {
		this.applicantId = applicantId;
	}
	
	
}
