package dao.payee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dao.bankapplicant.BankApplicant;

public class PayeeDAOImpl implements PayeeDAO {

	Connection conn;
	
	public PayeeDAOImpl() {
		try {
			//DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Driver loaded.../registered....");

			//conn = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "sysgitc");
			System.out.println("Connected to the db...."+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public Payee findPayeeByAccountNumber(int acno) {
		Payee payee = null;
		try {
			Statement st = conn.createStatement();
			System.out.println("statement is created..."+st);
			
			ResultSet rs = st.executeQuery("SELECT * FROM payee where payee_account_number="+acno);
			System.out.println("query fired...got the results....");
			

			if(rs.next()) {
				
				payee = new Payee();
				
				payee.setPayeeAccountNumber(rs.getInt(1));
				payee.setPayeeName(rs.getString(2));
				payee.setPayeeNickName(rs.getString(3));
				payee.setPayeeLimit(rs.getDouble(4));
				payee.setApplicantId(rs.getInt(5));
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return payee;
	}

	@Override
	public List<Payee> findAllPayees() {
		List<Payee> payeeList = new ArrayList<Payee>();
		Payee payee = null;
		try {
			Statement st = conn.createStatement();
			System.out.println("statement is created..."+st);
			
			ResultSet rs = st.executeQuery("SELECT * FROM payee ");
			System.out.println("query fired...got the results....");
			

			while(rs.next()) {
				
				payee = new Payee();
				
				payee.setPayeeAccountNumber(rs.getInt(1));
				payee.setPayeeName(rs.getString(2));
				payee.setPayeeNickName(rs.getString(3));
				payee.setPayeeLimit(rs.getDouble(4));
				payee.setApplicantId(rs.getInt(5));
				payeeList.add(payee);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return payeeList;
	}

	@Override
	public void savePayee(Payee p) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO payee VALUES (?,?,?,?,?) ");
			pst.setInt(1, p.getPayeeAccountNumber());
			pst.setString(2, p.getPayeeName());
			pst.setString(3, p.getPayeeNickName());
			pst.setDouble(4, p.getPayeeLimit());
			pst.setInt(5, p.getApplicantId());
			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row inserted..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void updatePayee(Payee p) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE payee set payee_limit=? where payee_account_number=? ");
			pst.setDouble(1, p.getPayeeLimit());
			pst.setInt(2, p.getPayeeAccountNumber());
			
			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row updated..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deletePayeeByAccountNumber(int acno) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement pst = conn.prepareStatement("delete from payee where payee_account_number=? ");
			pst.setDouble(1, acno);

			System.out.println("prepared statement is created..."+pst);
			int row = pst.executeUpdate();
			System.out.println("row deleted..."+row);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
