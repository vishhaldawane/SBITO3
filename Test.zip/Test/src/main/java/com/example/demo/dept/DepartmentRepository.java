package com.example.demo.dept;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository // <-- same as component	
public interface DepartmentRepository {
	
	public List<Department> getAllDepartments();

}
