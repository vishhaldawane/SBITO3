package com.example.demo.dept;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service		//4
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired		// 3
	DepartmentRepository deptRepository;
	
	@Override
	public List<Department> fetchAllDepartmentsService() {
		System.out.println("DepartmentServiceImpl: fetchAllDepartmentsService() is returning list....");
		return deptRepository.getAllDepartments();
				
		/*Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		
		System.out.println("Enter username : ");
		String username = scan1.next();
		System.out.println("Enter password : ");
		String password = scan2.next();
		
		if(username.equals("admin") && password.equals("admin123")) {
			System.out.println("Welcome admin...");
			List<Department> deptList= deptRepository.getAllDepartments();
			for (Department department : deptList) {
				System.out.println("DEPTNO : "+department.getDepartmentNumber());
				System.out.println("DNAME  : "+department.getDepartmentName());
				System.out.println("DLOC   : "+department.getDepartmentLocation());
				System.out.println("----------------------------------");
			}
		}
		else {
			throw new RuntimeException("Only admin can view all the departments...");
		}*/
	}
}
