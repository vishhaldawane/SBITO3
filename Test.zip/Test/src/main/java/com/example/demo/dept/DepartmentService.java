package com.example.demo.dept;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface DepartmentService {
	List<Department> fetchAllDepartmentsService();
}
