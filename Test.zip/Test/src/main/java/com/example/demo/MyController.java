package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dept.Department;
import com.example.demo.dept.DepartmentService;

@RestController
@RequestMapping("/bank")
public class MyController {
	
	@Autowired
	DepartmentService deptService;
	
	@GetMapping("/hi") // localhost:8080/bank/hi
	public String sayHello() {
		return "<h1>Welcome to the banking world</h1>"
				+ "<a href='dept'> See All Departments </a>"
				+ "<a href='login'> Login </a>"
				+ "<a href='register'> Register </a>";
	}

	@GetMapping("/login") // localhost:8080/bank/hi
	public String loginFromHere() {
		return "<h1>Login to the banking world</h1>";
	}
	
	@GetMapping("/register") // localhost:8080/bank/hi
	public String registerFromHere() {
		return "<h1>Register to the banking world</h1>";
	}
	
	@GetMapping("/dept") // localhost:8080/bank/hi
	public List<Department> findDeptListFromHere() {
		System.out.println("MyController : findDeptListFromHere() is returning list....");
		return deptService.fetchAllDepartmentsService();
	}

}
