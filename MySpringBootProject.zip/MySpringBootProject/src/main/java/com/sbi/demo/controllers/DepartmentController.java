package com.sbi.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.demo.entity.Department;
import com.sbi.demo.services.DepartmentService;

@RestController
@RequestMapping("/depts")
public class DepartmentController {

	@RequestMapping("/welcome")
	public String greet() { // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: greet() is invoked....");
	  return "<h1>Welcome to Department Controller</h1>";
	}
	
	@Autowired
	DepartmentService deptService;// new DepartmentServiceImpl();

	@RequestMapping("/")
	public List<Department> allDepts() { // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: allDepts() is invoked....");
	  return deptService.fetchAllDepartmentsService();
	}
	@RequestMapping("/{dno}")
	public Department findSingleDept(@PathVariable("dno") int deptno) { // http://localhost:8080/depts/welcome
	  System.out.println("DepartmentController: findSingleDept(int) is invoked....");
	  return deptService.fetchDepartmentByIdService(deptno);
	}
}
