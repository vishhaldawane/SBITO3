package com.sbi.demo.services;

import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.demo.entity.Department;
import com.sbi.demo.exceptions.DepartmentAlreadyExistsException;
import com.sbi.demo.exceptions.DepartmentNotFoundException;
import com.sbi.demo.repositories.DepartmentRepository;

@Service		//4
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired		// 3
	DepartmentRepository deptRepository;
	@Override
	public List<Department> fetchAllDepartmentsService() {
			List<Department> deptList= deptRepository.getAllDepartments();
			return deptList;
	}
	public Department fetchDepartmentByIdService(int id) throws DepartmentNotFoundException {
		Department dept=null;
		try {
			dept = deptRepository.getDepartmentById(id);
		} catch (DepartmentNotFoundException e) {
			throw e;
		}
		return dept;
	}
	public void addDepartmentService(Department dept) throws DepartmentAlreadyExistsException 
	{
		try {
			//...
			//...
			deptRepository.insertDepartment(dept);
			//...
			//..
		} catch (DepartmentAlreadyExistsException e) {
			throw e;
		}
	}
	public void modifyDepartmentService(Department dept) throws DepartmentNotFoundException {
		try {
			deptRepository.updateDepartment(dept);
		} catch (DepartmentNotFoundException e) {
			throw e;
		}
	}
	public void deleteDepartmentByIdService(int deptno) throws DepartmentNotFoundException{
		try {
			deptRepository.deleteDepartmentById(deptno);
		} catch (DepartmentNotFoundException e) {
				throw e;
		}
	}

	
}
