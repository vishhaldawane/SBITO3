package com.hdfc;

public class Piston {
	public void firePiston() {
		System.out.println("com.hdfc: Piston is fired...");
	}
}
