package com.hdfc;

public class Engine {
	Piston pist;
	public void setPistoneering(Piston p) {
		System.out.println("com.hdfc: setPiston(Piston)....");
		pist = p;
	}
	public void igniteTheEngine() {
		pist.firePiston();
		System.out.println("com.hdfc: igniteTheEngine()....");
	}
}
