package com.hdfc;
//Engine e = new Engine();
//Car c= new Car();
//c.setEngine(e);
public class Car {
	Engine eng;
	public void setEngineering(Engine e) {
		System.out.println("com.hdfc: setEngine(Engine)....");
		eng = e;
	}
	public void startTheCar() {
		eng.igniteTheEngine();
		System.out.println("com.hdfc: Car is started....");
	}
}
