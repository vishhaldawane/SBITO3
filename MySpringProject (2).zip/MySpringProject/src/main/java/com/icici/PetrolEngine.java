package com.icici;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PetrolEngine extends Engine {
	
	@Autowired
	Piston pist;
	
	public void igniteTheEngine() { //overriding
		pist.firePiston();
		System.out.println("com.icici: igniteTheEngine()....PetrolEngine....");
	}
}
