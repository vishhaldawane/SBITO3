package com.icici;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//Engine e = new Engine();
//Car c= new Car();
//c.setEngine(e);
@Component("x")
@Scope("prototype")
public class Car {
	
	@Autowired
	@Qualifier("petrolEngine")
	Engine pe; // automagically injected by spring f/w 
	
	public void startTheCar() {
		pe.igniteTheEngine();
		System.out.println("com.icici: Car is started....");
	}
}
