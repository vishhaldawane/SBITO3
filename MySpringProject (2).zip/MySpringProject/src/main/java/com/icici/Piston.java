package com.icici;

import org.springframework.stereotype.Component;

/*@Cash  @Money  @Wealth   @Amount  @BankBalance
@Component @Repository  @Service @RestController*/

@Component("z")
public class Piston {
	public void firePiston() {
		System.out.println("com.icici: Piston is fired...");
	}
}
