package com.sbi;

public class Engine {
	Piston pistObj;
	
	public Engine(Piston x) {
		System.out.println("Engine(Piston) ctor...");
		pistObj=x;
	}
	public void igniteTheEngine() {
		pistObj.firePiston();
		System.out.println("ingniting the engine...");
	}
}