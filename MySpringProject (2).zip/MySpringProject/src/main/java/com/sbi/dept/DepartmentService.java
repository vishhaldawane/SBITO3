package com.sbi.dept;

import org.springframework.stereotype.Service;

@Service
public interface DepartmentService {
	void fetchAllDepartmentsService();
}
