package com.sbi;
public class Car
{
	Engine engObj; //hasA
	
	public Car(Engine x) {
		System.out.println("Car(Engine) ctor...");
		engObj = x;
	}
	
	public void startCar() {
		engObj.igniteTheEngine();
		System.out.println("Car is started...");
	}
}