package com.sbi;

public class Piston{
	public Piston() {
		System.out.println("Piston() ctor...");
	}
	public void firePiston() {
		System.out.println("firing the piston....");
	}
}
