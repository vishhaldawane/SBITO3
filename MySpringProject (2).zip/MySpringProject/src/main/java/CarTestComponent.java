import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.icici.Car;
import com.icici.Engine;
import com.icici.Piston;

public class CarTestComponent {
	public static void main(String[] args) {
		
		System.out.println("trying to load the application context...");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspring4.xml");
		System.out.println("application context...loaded.....");
		System.out.println("-------------------");
		Car carObj = (Car) container.getBean("x");
		carObj.startTheCar();
		System.out.println("carObj "+carObj);
		System.out.println("-------------------");
				
		
	}
}
