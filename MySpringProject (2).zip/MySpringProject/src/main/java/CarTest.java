import com.sbi.Car;
import com.sbi.Engine;
import com.sbi.Piston;

//bean = pojo = component
public class CarTest {
	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		CarFactory carFactory = new CarFactory();
		
		Car car1 = carFactory.getACar();
		car1.startCar();
		System.out.println("----------------------");
		
		Car car2 = carFactory.getACar();
		car2.startCar();
		System.out.println("----------------------");
		
		Car car3 = carFactory.getACar();
		car3.startCar();
		
		
		//BeanFactory factory = new BeanFactory("something.xml");
		//Car car = factory.getBean("hintofTheBean");
	}
}



class Driver
{
	void driveTheCar() {
		Piston pistObj = new Piston();
		System.out.println("pistObj "+pistObj.hashCode());
		Engine engObj = new Engine(pistObj);
		System.out.println("engObj "+engObj.hashCode());
		Car carObj = new Car(engObj);
		System.out.println("carObj "+carObj.hashCode());
		carObj.startCar();
	}
}


class CarFactory
{
	Car getACar() {
		Piston pistObj = new Piston();
		System.out.println("pistObj "+pistObj.hashCode());
		Engine engObj = new Engine(pistObj);
		System.out.println("engObj "+engObj.hashCode());
		Car carObj = new Car(engObj);
		System.out.println("carObj "+carObj.hashCode());
		return carObj;
	}
}









