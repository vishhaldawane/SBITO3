import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.icici.Car;
import com.icici.Engine;
import com.icici.Piston;
import com.sbi.dept.Department;
import com.sbi.dept.DepartmentRepository;

public class DepartmentTest {
	public static void main(String[] args) {
		
		System.out.println("trying to load the application context...");
		ApplicationContext container = 
				new ClassPathXmlApplicationContext("myspring5.xml");
		System.out.println("application context...loaded.....");
		System.out.println("-------------------");
		DepartmentRepository departmentRepository = (DepartmentRepository ) container.getBean("deptRepo");
		
		List<Department> deptList = departmentRepository.getAllDepartments();
		for (Department department : deptList) {
			System.out.println("DEPTNO : "+department.getDepartmentNumber());
			System.out.println("DNAME  : "+department.getDepartmentName());
			System.out.println("DLOC   : "+department.getDepartmentLocation());
			System.out.println("----------------------------------");
		}
	}
}
