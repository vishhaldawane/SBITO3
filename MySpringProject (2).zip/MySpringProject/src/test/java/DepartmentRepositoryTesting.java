
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.sbi.dept.Department;
import com.sbi.dept.DepartmentRepository;
import com.sbi.dept.DepartmentRepositoryImpl;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:myspring5.xml"})
public class DepartmentRepositoryTesting { //Car
	@Autowired
	DepartmentRepositoryImpl departmentRepository; //Engine eng;

	@Test public void loadAllDepartments() {
		List<Department> deptList = departmentRepository.getAllDepartments();
		for (Department department : deptList) {
			System.out.println("DEPTNO : "+department.getDepartmentNumber());
			System.out.println("DNAME  : "+department.getDepartmentName());
			System.out.println("DLOC   : "+department.getDepartmentLocation());
			System.out.println("----------------------------------");
		}
		
	}
}



@Repository
interface Animal
{
	void breathing();
}

@Repository
class Human implements Animal {
	public void breathing() {
		
	}
	public void think() {
		
	}
}
