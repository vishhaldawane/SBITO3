import { Component, OnInit } from '@angular/core';
import { UserDetails } from '../user-details/UserDetails';

@Component({
  selector: 'app-add-user-details',
  templateUrl: './add-user-details.component.html',
  styleUrls: ['./add-user-details.component.css']
})
export class AddUserDetailsComponent implements OnInit {

  userDetails: UserDetails = new UserDetails();

  constructor() { }

  ngOnInit(): void {
  }

  addSingleUserDetails() {
    console.log('sending the user details to spring controller...');
  }

}
