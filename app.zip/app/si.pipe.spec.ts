import { SiPipe } from './si.pipe';

describe('SiPipe', () => {
  it('create an instance', () => {
    const pipe = new SiPipe();
    expect(pipe).toBeTruthy();
  });
});
