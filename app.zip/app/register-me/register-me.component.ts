import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-me',
  templateUrl: './register-me.component.html',
  styleUrls: ['./register-me.component.css']
})
export class RegisterMeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
