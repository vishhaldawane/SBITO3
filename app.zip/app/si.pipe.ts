import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'si'
})
export class SiPipe implements PipeTransform {
  transform(principal: any, year: any, rate: any,): number {
    console.log('principal ',principal);
    console.log('year  ',year);
    console.log('rate ',rate);
    return (principal*year*rate)/100;
  }
}
