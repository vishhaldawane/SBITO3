import { SquareRootPipe } from './square-root.pipe';

describe('SquareRootPipe', () => {
  it('create an instance', () => {
    const pipe = new SquareRootPipe();
    expect(pipe).toBeTruthy();
  });
});
