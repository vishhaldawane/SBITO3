import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteUserDetailsComponent } from './delete-user-details.component';

describe('DeleteUserDetailsComponent', () => {
  let component: DeleteUserDetailsComponent;
  let fixture: ComponentFixture<DeleteUserDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeleteUserDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteUserDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
