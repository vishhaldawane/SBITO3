import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-user-details',
  templateUrl: './delete-user-details.component.html',
  styleUrls: ['./delete-user-details.component.css']
})
export class DeleteUserDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
