import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-balance',
  templateUrl: './view-balance.component.html',
  styleUrls: ['./view-balance.component.css']
})
export class ViewBalanceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
