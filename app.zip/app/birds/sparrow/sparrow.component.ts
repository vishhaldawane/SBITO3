import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sparrow',
  templateUrl: './sparrow.component.html',
  styleUrls: ['./sparrow.component.css']
})
export class SparrowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
