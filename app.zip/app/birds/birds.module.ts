import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ParrotComponent } from './parrot/parrot.component';
import { SparrowComponent } from './sparrow/sparrow.component';
import { CrowComponent } from './crow/crow.component';



@NgModule({
  declarations: [
    ParrotComponent,
    SparrowComponent,
    CrowComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [ParrotComponent]
})
export class BirdsModule { }
