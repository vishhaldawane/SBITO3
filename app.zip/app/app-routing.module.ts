import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { LoginMeComponent } from './login-me/login-me.component';
import { MydashboardComponent } from './mydashboard/mydashboard.component';
import { OurCompanyComponent } from './our-company/our-company.component';
import { OurEmployeesComponent } from './our-employees/our-employees.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { RegisterMeComponent } from './register-me/register-me.component';
import { UsersModule } from './users/users.module';

// const routes: Routes = [
//   {
//       path:'about',
//       children: [
//         {path:'',component:AboutComponent},
//         {path:'our-emps',component:OurEmployeesComponent},
//         {path:'our-comp',component:OurCompanyComponent},
//       ]
//   },
//   {path:'login',component:LoginMeComponent},
//   {path:'register',component:RegisterMeComponent},
//   {path:'dashboard',component:DashBoardComponent},
//   {path:'admin-dashboard',component:AdminDashBoardComponent},
//   {path:'**',component:PageNotFoundComponent},
// ];

const routes: Routes = [
  {path:'',redirectTo:'mydashboard', pathMatch:'full'},
  {path:'mydashboard',component:MydashboardComponent},
  {path:'users',loadChildren: ()=> UsersModule},
  {path:'**',component:MydashboardComponent},
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
