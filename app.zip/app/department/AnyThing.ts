export class AnyThing { //DTO - data transfer object 
    dno!:number; //deptno
    eno!:number; //empno
    cno!:number; //custid

}
/*
    angular - AnyThing.ts - 3 fields - [ 30,  7654,500                  102 6000 ]  
    |                       [SALES, CHICAGO  MARTIN  1250 SALESMAN  VOLLYRITE,BURLINGAME]
    spring controller - DepartmentController, MailController
    |
    spring service - DepartmentService
    |
    spring repo - DepartmentRepo
    |
    spring pojo - Department
    |
    tables [ dept, emp, customer ]


*/