export class Department {
    departmentNumber!: number;
    departmentName!: string;
    departmentLocation!: string;
}