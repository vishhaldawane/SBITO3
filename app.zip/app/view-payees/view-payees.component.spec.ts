import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPayeesComponent } from './view-payees.component';

describe('ViewPayeesComponent', () => {
  let component: ViewPayeesComponent;
  let fixture: ComponentFixture<ViewPayeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPayeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPayeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
