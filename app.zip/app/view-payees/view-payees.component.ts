import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-payees',
  templateUrl: './view-payees.component.html',
  styleUrls: ['./view-payees.component.css']
})
export class ViewPayeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
