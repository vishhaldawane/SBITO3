import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-user-details',
  templateUrl: './update-user-details.component.html',
  styleUrls: ['./update-user-details.component.css']
})
export class UpdateUserDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
