import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'calc-si',
  templateUrl: './simple-interest-calculator.component.html',
  styleUrls: ['./simple-interest-calculator.component.css']
})
export class SimpleInterestCalculatorComponent implements OnInit {

  constructor() { 

  }

  ngOnInit(): void {
  }

  principal: number=50000;
  numberOfYears:number=10;
  rateOfInterest:number=7.8;
  simpleInterest:number=(this.principal*this.numberOfYears*this.rateOfInterest)/100;

  calculateSimpleInterest() {
    console.log('Principal : ',this.principal);
    console.log('Years : ',this.numberOfYears);
    console.log('Rate : ',this.rateOfInterest);
    this.simpleInterest=(this.principal*this.numberOfYears*this.rateOfInterest)/100;
    console.log('SI : ',this.simpleInterest);
  }

}
class SavingsAccount {
   accountNumber!:number ;
   accoutHolderName!: string;
   accountBalance!: number;

   withdraw(amt:number) : number { 
      return 0;
   }
   deposit() {

   }

}