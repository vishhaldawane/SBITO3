import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoseComponent } from './rose/rose.component';
import { LotusComponent } from './lotus/lotus.component';
import { LilyComponent } from './lily/lily.component';



@NgModule({
  declarations: [
    RoseComponent,
    LotusComponent,
    LilyComponent
  ],
  imports: [
    CommonModule
  ],
  exports : [ RoseComponent, LotusComponent, LilyComponent]
})
export class FlowersModule { }
