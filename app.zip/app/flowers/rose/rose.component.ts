import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rose',
  templateUrl: './rose.component.html',
  styleUrls: ['./rose.component.css']
})
export class RoseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
