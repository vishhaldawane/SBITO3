import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { TransferComponent } from '../transfer/transfer.component';
import { ViewBalanceComponent } from '../view-balance/view-balance.component';
import { ViewPayeesComponent } from '../view-payees/view-payees.component';

const dashBoardRouting: Routes = [
  {path:'view-balance',component:ViewBalanceComponent, outlet:'app-dash-board'},
  {path:'view-payees',component:ViewPayeesComponent},
  {path:'transfer',component:TransferComponent},
  {path:'**',component:PageNotFoundComponent},
];
@NgModule({
  //imports: [RouterModule.forRoot(routes)],
  imports: [RouterModule.forChild(dashBoardRouting)],
  exports: [RouterModule]
})
export class DashBaordRoutingModule { }
