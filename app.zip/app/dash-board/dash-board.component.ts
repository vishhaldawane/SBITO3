import { Component, OnInit } from '@angular/core';
import { User } from '../login-me/User';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.css']
})
export class DashBoardComponent implements OnInit {
  userObj: User = new User();
  constructor() { }
  anyObject: any;
  ngOnInit(): void {
    this.anyObject = sessionStorage.getItem("x");
    this.userObj = JSON.parse(this.anyObject);
  }

}
