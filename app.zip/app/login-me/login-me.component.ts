import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from './User';

@Component({
  selector: 'app-login-me',
  templateUrl: './login-me.component.html',
  styleUrls: ['./login-me.component.css']
})
export class LoginMeComponent implements OnInit {
  userObj: User = new User();
  constructor(private router:Router) { }
  ngOnInit(): void {  }
  authenticate() {
    if(this.userObj.username=="admin" && this.userObj.password=="admin123") {
      console.log('Welcome Admin User ');
      sessionStorage.setItem("x",JSON.stringify(this.userObj));
      this.router.navigate(['/admin-dashboard']);
    }
    else {
      console.log('Welcome End User ');
      sessionStorage.setItem("x",JSON.stringify(this.userObj));
      this.router.navigate(['/dashboard']);
    }
  }
}
