import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginMeComponent } from './login-me.component';

describe('LoginMeComponent', () => {
  let component: LoginMeComponent;
  let fixture: ComponentFixture<LoginMeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginMeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginMeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
