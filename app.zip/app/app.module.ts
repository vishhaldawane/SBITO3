import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import { SimpleInterestCalculatorComponent } from './simple-interest-calculator/simple-interest-calculator.component';
import { FormsModule } from '@angular/forms';
import { BankApplicantComponent } from './bank-applicant/bank-applicant.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { SquarePipe } from './square.pipe';
import { SquareRootPipe } from './square-root.pipe';
import { SiPipe } from './si.pipe';
import { BalancePipe } from './balance.pipe';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';
import { FlowersModule } from './flowers/flowers.module';
import { BirdsModule } from './birds/birds.module';
import { HttpClientModule }  from '@angular/common/http';
import { SingleUserDetailsComponent } from './single-user-details/single-user-details.component';
import { AddUserDetailsComponent } from './add-user-details/add-user-details.component';
import { UpdateUserDetailsComponent } from './update-user-details/update-user-details.component';
import { DeleteUserDetailsComponent } from './delete-user-details/delete-user-details.component';
import { DepartmentComponent } from './department/department.component';
import { AboutComponent } from './about/about.component';
import { OurEmployeesComponent } from './our-employees/our-employees.component';
import { OurCompanyComponent } from './our-company/our-company.component';
import { LoginMeComponent } from './login-me/login-me.component';
import { RegisterMeComponent } from './register-me/register-me.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { LogoutComponent } from './logout/logout.component';
import { ViewBalanceComponent } from './view-balance/view-balance.component';
import { ViewPayeesComponent } from './view-payees/view-payees.component';
import { TransferComponent } from './transfer/transfer.component';
import { MydashboardComponent } from './mydashboard/mydashboard.component';

@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    LoginComponent,
    SimpleInterestCalculatorComponent,
    BankApplicantComponent,
    UserDetailsComponent,
    SquarePipe,
    SquareRootPipe,
    SiPipe,
    BalancePipe,
    CurrencyConverterComponent,
    SingleUserDetailsComponent,
    AddUserDetailsComponent,
    UpdateUserDetailsComponent,
    DeleteUserDetailsComponent,
    DepartmentComponent,
    AboutComponent,
    OurEmployeesComponent,
    OurCompanyComponent,
    LoginMeComponent,
    RegisterMeComponent,
    DashBoardComponent,
    PageNotFoundComponent,
    AdminDashBoardComponent,
    LogoutComponent,
    ViewBalanceComponent,
    ViewPayeesComponent,
    TransferComponent,
    MydashboardComponent
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    FlowersModule,
    BirdsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
