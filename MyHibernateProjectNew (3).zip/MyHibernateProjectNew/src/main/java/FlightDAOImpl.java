import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FlightDAOImpl implements FlightDAO {

	EntityManager entityManager;
	
	public FlightDAOImpl () {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory : "+entityManagerFactory );
		this.entityManager = entityManagerFactory.createEntityManager();
		System.out.println("EntityManager: "+entityManager);
	}
	
	@Override
	public Flight findFlightById(int flno) {
		return entityManager.find(Flight.class, flno);
	}

	@Override
	public List<Flight> findAllFlights() {
		Query query = entityManager.createQuery("from Flight"); //select * from Flight
		return query.getResultList();
	}

	@Override
	public void saveFlight(Flight flight) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			entityManager.persist(flight);
		et.commit();

	}

	@Override
	public void updateFlight(Flight flight) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			entityManager.merge(flight);
		et.commit();

	}

	@Override
	public void deleteFlight(int flno) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
			Flight f = entityManager.find(Flight.class, flno);
			entityManager.remove(f);
		et.commit();
	}

}
