import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class FlowerTest {
	public static void main(String[] args) {
		/*	Flower f 				 =  Garden.createFlower("lake");
			Perfume p= f.fragrance();
			p.topNote();
			p.middleNote();
			p.baseNote();
			*/
			
			
			EntityManagerFactory entityManagerFactory = 	Persistence.createEntityManagerFactory("MyJPA");	//META-INF/persistence.xml -> persistence-unit name
			System.out.println("EntityManagerFactory : "+entityManagerFactory);
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			System.out.println("EntityManager: "+entityManager);
			
			//EntityTransaction et = entityManager.getTransaction();
			//et.begin();
					Flight flightObj = new Flight();
					System.out.println("Flight object is created....");
					flightObj.setFlightName("Air India");
					flightObj.setFlightSource("Mumbai");
					flightObj.setFlightDestination("New Delhi");
					flightObj.setFlightDepartureFromSource(LocalDateTime.of(2022,05,10,20,50));
					flightObj.setFlightArrivalAtDestination(LocalDateTime.of(2022,05,10,22,50));
					flightObj.setNumberOfPassengers(200);
					flightObj.setFlightTicketCost(7500);
					
					System.out.println("Flight object is filled up....");
					
					System.out.println("Trying to persist the Flight object ....");
					entityManager.persist(flightObj);
					System.out.println("Persisted the Flight object ....");
			//et.commit();
			
	}
}
class Garden
{
	static Flower createFlower() { //default is Rose
		return new Rose();
	}
	
	static Flower createFlower(String hint) { //based on the hint 
		Flower f = null;
		
		if(hint.equalsIgnoreCase("lake"))
			f = new Lotus();
		else if(hint.equalsIgnoreCase("garden"))
			f = new Lily();
		else if(hint.equalsIgnoreCase("valentine"))
			f= new Rose();
		
		return f;
	}
}
interface Perfume {
	void topNote();
	void middleNote();
	void baseNote();
}
class PoloBlack implements Perfume
{
	public void topNote() {
		System.out.println("Lemon");
	}
	public void middleNote() {
		System.out.println("Nagarmotha");
	}
	public void baseNote() {
		System.out.println("Amber");
	}
}
class PoloRed implements Perfume
{
	public void topNote() {
		System.out.println("Bergamot");
	}
	public void middleNote() {
		System.out.println("Patchouli");
	}
	public void baseNote() {
		System.out.println("Musk");
	}
}

class PoloGreen implements Perfume
{
	public void topNote() {
		System.out.println("Peach");
	}
	public void middleNote() {
		System.out.println("Lavender");
	}
	public void baseNote() {
		System.out.println("Patchouli");
	}
}

interface Flowering
{
	public Perfume fragrance();
}
abstract class Flower implements Flowering {
	
}
class Rose extends Flower 
{
	public Perfume fragrance() {
		System.out.println("Rose is flowering...at the garden....");
		 Perfume p = new  PoloBlack ();
		 return p;
	}
}
class Lotus extends Flower implements Flowering
{
	public Perfume fragrance() {
		System.out.println("Lotus is flowering...at the lake....");
		Perfume p = new  PoloRed();
		 return p;
	}
}
class Lily extends Flower implements Flowering
{
	public Perfume fragrance() {
		System.out.println("Lily is flowering...at the park....");
		Perfume p = new  PoloGreen();
		 return p;
	}
}


