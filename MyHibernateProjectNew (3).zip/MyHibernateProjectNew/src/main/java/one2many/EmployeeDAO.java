package one2many;

import java.util.List;

public interface EmployeeDAO {

	//assume 5 methods are there 
	
	List<Employee> findAllEmployees();
	void changeDepartmentOfSpecificEmployees(int oldDeptNo, int newDeptNo);
}
