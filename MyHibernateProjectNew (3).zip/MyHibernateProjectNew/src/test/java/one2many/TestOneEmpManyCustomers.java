package one2many;

import java.util.List;

import org.junit.jupiter.api.Test;

public class TestOneEmpManyCustomers {

	EmployeeDAO empDAO = new EmployeeDAOImpl();
	
	@Test
	public void loadAllSalesmanAndThierCustomers() {
		
		List<Employee> empList = empDAO.findAllEmployees();
		
		for (Employee emp : empList) 
		{
			if(emp.getJob().equals("SALESMAN"))
			{
				System.out.println("EMP number : "+emp.getEmployeeNumber());
				System.out.println("EMP name   : "+emp.getEmployeeName());
				System.out.println("EMP job    : "+emp.getJob());
				System.out.println("EMP mgr    : "+emp.getEmployeeManagerCode());
				System.out.println("EMP doj    : "+emp.getJoiningDate());
				System.out.println("EMP salary : "+emp.getBasicSalary());
				System.out.println("EMP comm   : "+emp.getCommission());
				System.out.println("EMP dept no: "+emp.getDepartment().getDepartmentNumber());
				System.out.println("------------------------");
				
				List<Customer> listOfCustomers= emp.getCustomerList();
				for (Customer customer : listOfCustomers) {
					System.out.println("Customer Id      : "+customer.getCustomerId());
					System.out.println("Customer Name    : "+customer.getCustomerName());
					System.out.println("Customer Address : "+customer.getAddress());
					System.out.println("Customer City    : "+customer.getCity());
					System.out.println("Customer State   : "+customer.getState());
					System.out.println("Customer Area    : "+customer.getArea());
					System.out.println("Customer Phone   : "+customer.getPhone());
					System.out.println("Customer Repid   : "+customer.getEmployee().getEmployeeNumber());
					System.out.println("Customer Comments: "+customer.getComments());
					System.out.println("******************************");
				}
			}
		}
	}
}
